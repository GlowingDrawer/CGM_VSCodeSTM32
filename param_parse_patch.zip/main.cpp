#include "main.h"
#include "DACManager.h"
#include "ADCManager.h"
#include "BTCPP.h"
#include "SysTickTimer.h"
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <cstdlib>

// ==================== Forward Declarations ====================

static inline void SendJsonLine(
    USART_Controller& usart,
    uint32_t ms,
    uint16_t uric_raw,
    uint16_t ascorbic_raw,
    uint16_t glucose_raw,
    uint16_t code12
);

enum class CommandType {
    START,
    PAUSE,
    RESUME,
    STOP,
    UNKNOWN
};

// ==================== Runtime Config (defaults) ====================
// 说明：只有收到参数变更命令时才会修改这些值；否则保持默认。
static NS_DAC::RunMode g_mode = NS_DAC::RunMode::CV;
static NS_DAC::CV_VoltParams g_cvVolt(0.8f, -0.8f, 1.65f); // HIGH/LOW 为相对电位；OFF 为中点偏置(V)
static NS_DAC::CV_Params g_cvParams(0.05f, 0.05f, NS_DAC::ScanDIR::FORWARD); // DUR(s), RATE(V/s)
static DPV_Params g_dpvParams{}; // 结构体内已带默认值
static uint16_t g_biasCode = 2048; // 0..4095，约等于 1.65V

static inline uint16_t ClampU16(uint32_t v, uint16_t lo, uint16_t hi) {
    if (v < lo) return lo;
    if (v > hi) return hi;
    return (uint16_t)v;
}

static void ApplyConfigToSystem() {
    auto& sys = NS_DAC::SystemController::GetInstance();
    sys.SetMode(g_mode);
    sys.SetCVParams(g_cvVolt, g_cvParams);
    sys.SetDPVParams(g_dpvParams);
    sys.SetConstantVal(g_biasCode);
}

static void PrintHelp(USART_Controller& usart) {
    usart.Printf(
        "Commands:\r\n"
        "  START | PAUSE | RESUME | STOP\r\n"
        "  MODE CV|DPV|IT\r\n"
        "  CV  HIGH=<v> LOW=<v> OFF=<v> DUR=<s> RATE=<v/s> DIR=FWD|REV\r\n"
        "  DPV START=<v> END=<v> STEP=<v> PULSE=<v> PER=<ms> WIDTH=<ms> OFF=<v>\r\n"
        "  IT  CODE=<0..4095>   (sets constant DAC code)\r\n"
        "Notes:\r\n"
        "  - CV/DPV 电位参数单位为 V(相对电位)，OFF 为中点偏置(绝对电压, V)。\r\n"
        "  - 参数命令在运行中也可下发，但通常在下一次 START 生效；MODE 需 STOP 后再改。\r\n"
    );
}

static bool TokKeyEq(const char* token, const char* key) {
    if (!token || !key) return false;
    const char* eq = std::strchr(token, '=');
    if (!eq) return false;
    const size_t klen = (size_t)(eq - token);
    const size_t keylen = std::strlen(key);
    if (klen != keylen) return false;
    for (size_t i = 0; i < klen; ++i) {
        char a = token[i];
        char b = key[i];
        if (a >= 'a' && a <= 'z') a = (char)(a - 'a' + 'A');
        if (b >= 'a' && b <= 'z') b = (char)(b - 'a' + 'A');
        if (a != b) return false;
    }
    return true;
}

static bool ParseFloatKV(const char* token, const char* key, float& out) {
    if (!TokKeyEq(token, key)) return false;
    const char* eq = std::strchr(token, '=');
    if (!eq || !eq[1]) return false;
    char* endp = nullptr;
    const float v = std::strtof(eq + 1, &endp);
    if (endp == (eq + 1)) return false;
    out = v;
    return true;
}

static bool ParseU32KV(const char* token, const char* key, uint32_t& out) {
    if (!TokKeyEq(token, key)) return false;
    const char* eq = std::strchr(token, '=');
    if (!eq || !eq[1]) return false;
    char* endp = nullptr;
    const unsigned long v = std::strtoul(eq + 1, &endp, 10);
    if (endp == (eq + 1)) return false;
    out = (uint32_t)v;
    return true;
}

static int  my_stricmp(const char* s1, const char* s2);
static void trim_inplace(char* s);
static bool TryReadCommandLine(USART_Controller& usart, char* outLine, uint16_t outCap);

// 参数解析辅助
static bool TokenKeyEqualsI(const char* token, const char* key, const char** outValStr);
static bool ParseFloatKV(const char* token, const char* key, float& ioVal);
static bool ParseU32KV(const char* token, const char* key, uint32_t& ioVal);
static bool ParseDirKV(const char* token, const char* key, NS_DAC::ScanDIR& ioDir);
static uint16_t Clamp12U16(int32_t v);

static void ApplyConfigToSystemController();
static void PrintHelp(USART_Controller& usart);
static const char* ModeToString(NS_DAC::RunMode m);
static CommandType ProcessCommandLine(
    USART_Controller& usart,
    const char* line,
    CommandType lastState
);

// ============================== main ==============================

int main(void) {

    // main.cpp
    SysTickTimer::Init();
    NVIC_SetPriority(SysTick_IRQn, 0); // 强制设为最高优先级！

    OLED_Init();

    auto& bt = GetStaticBt();
    USART_IRQnManage::Add(bt.GetParams().USART, USART::IT::RXNE, BT_IRQHandler, 1, 3);
    bt.Start();

    // 将默认参数写入 SystemController（如果未收到参数命令，这些默认值将一直使用）
    ApplyConfigToSystemController();

    bt.Printf("Ready. Use HELP for commands.\r\n");

    CommandType currentCommand = CommandType::UNKNOWN;
    bt.Printf("Waiting For Command... (START)\r\n");

    // 2. 记录实验开始的时间戳
    uint32_t startTime = 0;

    // 等待 START（更快响应）
    while (currentCommand != CommandType::START) {
        char line[64];
        if (TryReadCommandLine(bt, line, sizeof(line))) {
            currentCommand = ProcessCommandLine(bt, line, currentCommand);
            // 如果收到 START，立即记录时间基准
            if (currentCommand == CommandType::START) {
                startTime = SysTickTimer::GetTick();
            }
        }
        SysTickTimer::DelayMs(20);
    }

    // Show.patched：必须在主循环调用 adc.Service()
    auto& adc = NS_ADC::GetStaticADC();
    const auto& current16BitBuf = adc.GetDmaBufferRef();

    // CV 电压/Code值引用 (兼容旧接口)
    const auto& cvValRef = NS_DAC::GetCvValToSendRef();

    // 【修改点】：不再依赖 SystemController 的 tick 计数
    // const auto& sysUpdataTimes = NS_DAC::SystemController::GetTickCount(); (删除)

    uint32_t lastReportTime = 0;
    const uint32_t REPORT_INTERVAL = 50; // 50ms 上报一次

    while (1) {
        // 1) 命令优先处理
        char line[64];
        if (TryReadCommandLine(bt, line, sizeof(line))) {
            CommandType newCmd = ProcessCommandLine(bt, line, currentCommand);
            
            // 如果是从非运行状态切换到 START，重置时间 (可选)
            if (newCmd == CommandType::START && currentCommand != CommandType::START) {
                startTime = SysTickTimer::GetTick();
            }
            currentCommand = newCmd;
        }

        // 2) 关键：主循环刷新 OLED
        adc.Service();
       
        // 3) 使用 SysTick 控制上报频率
        uint32_t now = SysTickTimer::GetTick();
        // bt.Printf("Waiting For Command... (%lu)\r\n", (unsigned long)now);
        if (now - lastReportTime >= REPORT_INTERVAL)
        {
            lastReportTime = now;

            if (currentCommand == CommandType::START || currentCommand == CommandType::RESUME)
            {
                // 让 SystemController 更新内部状态(如果需要)
                NS_DAC::SystemController::GetInstance().UpdateTick();

                // 【修改点】：直接计算相对时间
                // 这样无论 DAC 频率是多少，上位机收到的都是真实的毫秒时间轴
                uint32_t ms = now - startTime;

                // ADC 原始值
                uint16_t uric_raw     = current16BitBuf[0];
                uint16_t ascorbic_raw = current16BitBuf[1];
                uint16_t glucose_raw  = current16BitBuf[2];

                // 12bit 码值
                uint16_t code12 = ((uint16_t)cvValRef) & 0x0FFF; // 保险：强制 12-bit

                SendJsonLine(bt, ms, uric_raw, ascorbic_raw, glucose_raw, code12);
            }
        }
        
        // 适当延时让出时间片，SysTick 计数不受 Delay 影响
        SysTickTimer::DelayMs(10);
    }
}

// ==================== Function Definitions ====================

static inline void SendJsonLine(
    USART_Controller& usart,
    uint32_t ms,
    uint16_t uric_raw,
    uint16_t ascorbic_raw,
    uint16_t glucose_raw,
    uint16_t code12
) {
    char outBuf[160];

    // snprintf 格式化 JSON
    int n = std::snprintf(outBuf, sizeof(outBuf),
        "{\"Ms\":%lu,\"Uric\":%u,\"Ascorbic\":%u,\"Glucose\":%u,\"Code12\":%u}\n",
        (unsigned long)ms,
        (unsigned)uric_raw,
        (unsigned)ascorbic_raw,
        (unsigned)glucose_raw,
        (unsigned)code12
    );

    if (n <= 0) return;

    if (n >= (int)sizeof(outBuf)) {
        outBuf[sizeof(outBuf) - 2] = '\n';
        outBuf[sizeof(outBuf) - 1] = '\0';
        n = (int)sizeof(outBuf) - 1;
    }

    usart.Write(reinterpret_cast<const uint8_t*>(outBuf), (uint16_t)n);
}

static int my_stricmp(const char* s1, const char* s2) {
    while (*s1 && *s2) {
        char c1 = (*s1 >= 'a' && *s1 <= 'z') ? (*s1 - 'a' + 'A') : *s1;
        char c2 = (*s2 >= 'a' && *s2 <= 'z') ? (*s2 - 'a' + 'A') : *s2;
        if (c1 != c2) return (unsigned char)c1 - (unsigned char)c2;
        ++s1; ++s2;
    }
    return (unsigned char)*s1 - (unsigned char)*s2;
}

static void trim_inplace(char* s) {
    if (!s) return;
    char* p = s;
    while (*p == ' ' || *p == '\t') ++p;
    if (p != s) std::memmove(s, p, std::strlen(p) + 1);
    size_t n = std::strlen(s);
    while (n > 0 && (s[n - 1] == ' ' || s[n - 1] == '\t')) {
        s[n - 1] = '\0';
        --n;
    }
}

static bool TryReadCommandLine(USART_Controller& usart, char* outLine, uint16_t outCap) {
    static char lineBuf[64];
    static uint16_t lineLen = 0;
    static bool dropping = false;

    uint8_t rxTmp[64];
    // 读取数据
    uint16_t n = usart.Receiver(rxTmp, (uint16_t)(sizeof(rxTmp) - 1));
    if (n == 0) return false;

    // 【调试代码】打印收到的原始 HEX 数据，看看有没有 0D 0A
    /*
    usart.Printf("RX[%d]: ", n);
    for(int k=0; k<n; k++) usart.Printf("%02X ", rxTmp[k]);
    usart.Printf("\r\n");
    */

    for (uint16_t i = 0; i < n; ++i) {
        char ch = (char)rxTmp[i];
        
        // 【调试代码】打印正在处理的字符
        // usart.Printf("Proc: %c (%02X)\r\n", ch, ch);

        if (ch == '\r' || ch == '\n') {
            if (dropping) {
                dropping = false;
                lineLen = 0;
                continue;
            }
            if (lineLen == 0) continue; // 忽略空行

            lineBuf[lineLen] = '\0';
            
            // 【调试代码】打印最终拼凑出的行
            usart.Printf("Line: [%s]\r\n", lineBuf);

            if (outCap > 0) {
                std::strncpy(outLine, lineBuf, outCap - 1);
                outLine[outCap - 1] = '\0';
            }
            lineLen = 0;
            return true; // 只有收到回车才返回 true
        }

        if (dropping) continue;

        if (lineLen < (uint16_t)(sizeof(lineBuf) - 1)) {
            lineBuf[lineLen++] = ch;
            // lineBuf[lineLen] = '\0'; // 这句没必要，最后补0即可
        } else {
            // 缓冲区满了，开始丢弃直到换行
            dropping = true;
            lineLen = 0;
            usart.Printf("Buffer Overflow! Dropping...\r\n");
        }
    }
    return false;
}

static CommandType ProcessCommandLine(
    USART_Controller& usart,
    const char* line,
    CommandType lastState
) {
    if (!line || !line[0]) return lastState;

    // 当前是否处于“运行态”（START/PAUSE/RESUME 都算运行态；STOP/UNKNOWN 视为未运行）
    const bool isRunningState = (lastState == CommandType::START || lastState == CommandType::PAUSE || lastState == CommandType::RESUME);

    char buf[128];
    std::strncpy(buf, line, sizeof(buf) - 1);
    buf[sizeof(buf) - 1] = '\0';
    trim_inplace(buf);
    if (buf[0] == '\0') return lastState;

    // Tokenize: CMD [ARG...]，支持空格/逗号分隔
    char* tok = std::strtok(buf, "\t ,");
    if (!tok) return lastState;

    // ============== HELP / SHOW ==============
    if (my_stricmp(tok, "HELP") == 0) {
        PrintHelp(usart);
        return lastState;
    }
    if (my_stricmp(tok, "SHOW") == 0) {
        usart.Printf("Mode=%s\r\n", (g_mode == NS_DAC::RunMode::CV) ? "CV" : (g_mode == NS_DAC::RunMode::DPV ? "DPV" : "IT"));
        usart.Printf("CV  HIGH=%.3f LOW=%.3f OFF=%.3f DUR=%.4f RATE=%.4f DIR=%s\r\n",
            (double)g_cvVolt.highVolt, (double)g_cvVolt.lowVolt, (double)g_cvVolt.voltOffset,
            (double)g_cvParams.duration, (double)g_cvParams.rate,
            (g_cvParams.dir == NS_DAC::ScanDIR::FORWARD) ? "FWD" : "REV");
        usart.Printf("DPV START=%.3f END=%.3f STEP=%.4f PULSE=%.4f PER=%u WIDTH=%u LEAD=%u OFF=%.3f\r\n",
            (double)g_dpvParams.startVolt, (double)g_dpvParams.endVolt, (double)g_dpvParams.stepVolt,
            (double)g_dpvParams.pulseAmp,
            (unsigned)g_dpvParams.pulsePeriodMs, (unsigned)g_dpvParams.pulseWidthMs, (unsigned)g_dpvParams.sampleLeadMs,
            (double)g_dpvParams.midVolt);
        usart.Printf("BIAS CODE=%u\r\n", (unsigned)g_biasCode);
        return lastState;
    }

    // ============== START / STOP / PAUSE / RESUME ==============
    if (my_stricmp(tok, "START") == 0) {
        usart.Printf("Starting...\r\n");
        NS_DAC::SystemController::GetInstance().Start();
        return CommandType::START;
    }
    if (my_stricmp(tok, "STOP") == 0) {
        usart.Printf("Stopping...\r\n");
        NS_DAC::SystemController::GetInstance().Stop();

        // STOP 后立即把最近一次参数修改应用到 SystemController（确保下一次 START 生效）
        ApplyConfigToSystemController();
        return CommandType::STOP;
    }
    if (my_stricmp(tok, "PAUSE") == 0) {
        if (lastState != CommandType::START && lastState != CommandType::RESUME) {
            usart.Printf("Error: PAUSE only valid after START/RESUME.\r\n");
            return lastState;
        }
        usart.Printf("Paused.\r\n");
        NS_DAC::SystemController::GetInstance().Pause();
        return CommandType::PAUSE;
    }
    if (my_stricmp(tok, "RESUME") == 0) {
        if (lastState != CommandType::PAUSE) {
            usart.Printf("Resume ignored. Device is not paused.\r\n");
            return lastState;
        }
        usart.Printf("Resumed.\r\n");
        NS_DAC::SystemController::GetInstance().Resume();
        return CommandType::RESUME;
    }

    // ============== MODE CV|DPV|IT ==============
    if (my_stricmp(tok, "MODE") == 0) {
        char* m = std::strtok(nullptr, "\t ,");
        if (!m) {
            usart.Printf("Error: MODE requires argument CV|DPV|IT\r\n");
            return lastState;
        }
        if (my_stricmp(m, "CV") == 0) g_mode = NS_DAC::RunMode::CV;
        else if (my_stricmp(m, "DPV") == 0) g_mode = NS_DAC::RunMode::DPV;
        else if (my_stricmp(m, "IT") == 0) g_mode = NS_DAC::RunMode::IT;
        else {
            usart.Printf("Error: unknown MODE=%s\r\n", m);
            return lastState;
        }

        if (!isRunningState) {
            ApplyConfigToSystemController();
            usart.Printf("MODE set to %s\r\n", m);
        } else {
            usart.Printf("MODE updated (will take effect after STOP then START).\r\n");
        }
        return lastState;
    }

    // ============== CV / DPV / IT 参数变更 ==============
    if (my_stricmp(tok, "CV") == 0) {
        // CV HIGH=... LOW=... OFF=... DUR=... RATE=... DIR=FWD|REV
        char* t = nullptr;
        while ((t = std::strtok(nullptr, "\t ,")) != nullptr) {
            ParseFloatKV(t, "HIGH", g_cvVolt.highVolt);
            ParseFloatKV(t, "LOW",  g_cvVolt.lowVolt);
            ParseFloatKV(t, "OFF",  g_cvVolt.voltOffset);
            ParseFloatKV(t, "DUR",  g_cvParams.duration);
            ParseFloatKV(t, "RATE", g_cvParams.rate);
            ParseDirKV(t,   "DIR",  g_cvParams.dir);
        }

        // 保护：high>=low
        if (g_cvVolt.highVolt < g_cvVolt.lowVolt) {
            float tmp = g_cvVolt.highVolt; g_cvVolt.highVolt = g_cvVolt.lowVolt; g_cvVolt.lowVolt = tmp;
        }
        if (g_cvParams.duration <= 0.0f) g_cvParams.duration = 0.001f;
        if (g_cvParams.rate <= 0.0f) g_cvParams.rate = 0.001f;

        if (!isRunningState) ApplyConfigToSystemController();
        usart.Printf("CV params updated%s\r\n", isRunningState ? " (apply after STOP/START)" : "");
        return lastState;
    }

    if (my_stricmp(tok, "DPV") == 0) {
        // DPV START=... END=... STEP=... PULSE=... PER=.. WIDTH=.. LEAD=.. OFF=..
        uint32_t tmpU32 = 0;
        char* t = nullptr;
        while ((t = std::strtok(nullptr, "\t ,")) != nullptr) {
            ParseFloatKV(t, "START", g_dpvParams.startVolt);
            ParseFloatKV(t, "END",   g_dpvParams.endVolt);
            ParseFloatKV(t, "STEP",  g_dpvParams.stepVolt);
            ParseFloatKV(t, "PULSE", g_dpvParams.pulseAmp);
            if (ParseU32KV(t, "PER", tmpU32))   g_dpvParams.pulsePeriodMs = (uint16_t)tmpU32;
            if (ParseU32KV(t, "WIDTH", tmpU32)) g_dpvParams.pulseWidthMs  = (uint16_t)tmpU32;
            if (ParseU32KV(t, "LEAD", tmpU32))  g_dpvParams.sampleLeadMs  = (uint16_t)tmpU32;
            ParseFloatKV(t, "OFF",   g_dpvParams.midVolt);
        }

        // 基本保护
        if (g_dpvParams.pulsePeriodMs == 0) g_dpvParams.pulsePeriodMs = 1;
        if (g_dpvParams.pulseWidthMs == 0)  g_dpvParams.pulseWidthMs  = 1;
        if (g_dpvParams.pulseWidthMs >= g_dpvParams.pulsePeriodMs) {
            g_dpvParams.pulseWidthMs = (g_dpvParams.pulsePeriodMs > 1) ? (g_dpvParams.pulsePeriodMs - 1) : 1;
        }

        if (!isRunningState) ApplyConfigToSystemController();
        usart.Printf("DPV params updated%s\r\n", isRunningState ? " (apply after STOP/START)" : "");
        return lastState;
    }

    if (my_stricmp(tok, "IT") == 0 || my_stricmp(tok, "BIAS") == 0) {
        // IT CODE=...  或  IT VABS=...
        uint32_t tmpU32 = 0;
        float vabs = 0.0f;

        char* t = nullptr;
        while ((t = std::strtok(nullptr, "\t ,")) != nullptr) {
            if (ParseU32KV(t, "CODE", tmpU32)) {
                g_biasCode = Clamp12U16((int32_t)tmpU32);
            }
            if (ParseFloatKV(t, "VABS", vabs)) {
                // VABS: 0..Vref，默认按 3.3V
                if (vabs < 0.0f) vabs = 0.0f;
                if (vabs > 3.3f) vabs = 3.3f;
                const float codeF = (vabs / 3.3f) * 4095.0f;
                g_biasCode = Clamp12U16((int32_t)(codeF + 0.5f));
            }
        }
        if (!isRunningState) ApplyConfigToSystemController();
        usart.Printf("BIAS updated%s\r\n", isRunningState ? " (apply after STOP/START)" : "");
        return lastState;
    }

    usart.Printf("Unknown command: %s. Use HELP.\r\n", tok);
    return lastState;
}

// ==================== Param Parse Helpers ====================

static uint16_t Clamp12U16(int32_t v) {
    if (v < 0) return 0;
    if (v > 4095) return 4095;
    return (uint16_t)v;
}

// 判断 token 是否形如 KEY=...（忽略大小写），若匹配返回 true 并输出 value 字符串指针
static bool TokenKeyEqualsI(const char* token, const char* key, const char** outValStr) {
    if (!token || !key) return false;
    const char* eq = std::strchr(token, '=');
    if (!eq) return false;
    const size_t klen = (size_t)(eq - token);
    const size_t keylen = std::strlen(key);
    if (klen != keylen) return false;
    for (size_t i = 0; i < klen; ++i) {
        char c1 = token[i];
        char c2 = key[i];
        if (c1 >= 'a' && c1 <= 'z') c1 = (char)(c1 - 'a' + 'A');
        if (c2 >= 'a' && c2 <= 'z') c2 = (char)(c2 - 'a' + 'A');
        if (c1 != c2) return false;
    }
    if (outValStr) *outValStr = eq + 1;
    return true;
}

static bool ParseFloatKV(const char* token, const char* key, float& ioVal) {
    const char* vstr = nullptr;
    if (!TokenKeyEqualsI(token, key, &vstr) || !vstr) return false;
    char* endp = nullptr;
    const float v = std::strtof(vstr, &endp);
    if (endp == vstr) return false;
    ioVal = v;
    return true;
}

static bool ParseU32KV(const char* token, const char* key, uint32_t& ioVal) {
    const char* vstr = nullptr;
    if (!TokenKeyEqualsI(token, key, &vstr) || !vstr) return false;
    char* endp = nullptr;
    const unsigned long v = std::strtoul(vstr, &endp, 10);
    if (endp == vstr) return false;
    ioVal = (uint32_t)v;
    return true;
}

static bool ParseDirKV(const char* token, const char* key, NS_DAC::ScanDIR& ioDir) {
    const char* vstr = nullptr;
    if (!TokenKeyEqualsI(token, key, &vstr) || !vstr) return false;
    if (my_stricmp(vstr, "FWD") == 0 || my_stricmp(vstr, "FORWARD") == 0) {
        ioDir = NS_DAC::ScanDIR::FORWARD;
        return true;
    }
    if (my_stricmp(vstr, "REV") == 0 || my_stricmp(vstr, "REVERSE") == 0) {
        ioDir = NS_DAC::ScanDIR::REVERSE;
        return true;
    }
    return false;
}

static void ApplyConfigToSystemController() {
    auto& sys = NS_DAC::SystemController::GetInstance();
    sys.SetMode(g_mode);
    sys.SetCVParams(g_cvVolt, g_cvParams);
    sys.SetDPVParams(g_dpvParams);
    sys.SetConstantVal(g_biasCode);
}

static void PrintHelp(USART_Controller& usart) {
    usart.Printf("Commands:\r\n");
    usart.Printf("  START | STOP | PAUSE | RESUME\r\n");
    usart.Printf("  MODE CV|DPV|IT\r\n");
    usart.Printf("  CV  HIGH=.. LOW=.. OFF=.. DUR=.. RATE=.. DIR=FWD|REV\r\n");
    usart.Printf("  DPV START=.. END=.. STEP=.. PULSE=.. PER=.. WIDTH=.. LEAD=.. OFF=..\r\n");
    usart.Printf("  IT  CODE=0..4095   (or)  IT VABS=0..3.3\r\n");
    usart.Printf("  SHOW   (print current cached params)\r\n");
    usart.Printf("Notes:\r\n");
    usart.Printf("  - If parameters are changed while running, they take effect after STOP then START.\r\n");
    usart.Printf("  - Volt units are in V (not mV). Example: PULSE=0.05 means 50mV.\r\n");
}